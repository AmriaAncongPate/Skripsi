
<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            <?php if(Session::has('buket')): ?>
            <?php echo Session::get('buket'); ?>

            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($title); ?></h4>
                </div>
                <div class="card-body">
                    <form action="/updatebkt" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="buket_id" value="<?php echo e($buket->id); ?>">
                    <div class="mb-3">
                      <label for="buket" class="form-label">Nama Buket</label>
                      <input type="text" class="form-control" id="buket" name="buket" value="<?php echo e($buket->buket); ?>">
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="/buket" class="btn btn-info">Kembali</a>
                    </div>
                  </form>
                </div>
            </div>
        </dov>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tempadmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amriapk\resources\views/admin/edit-buket.blade.php ENDPATH**/ ?>