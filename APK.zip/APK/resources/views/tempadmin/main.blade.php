<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{$title}}</title>
  <link rel="shortcut icon" type="image/png" href="/assets/images/logos/favicon.png" />
  <link rel="stylesheet" href="/assets/css/styles.min.css" />
  
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" />
</head>
<body>
  <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
    data-sidebar-position="fixed" data-header-position="fixed">
    <aside class="left-sidebar">
      <div>
        <div class="brand-logo d-flex align-items-center justify-content-between">
          <a href="/" class="text-nowrap logo-img">
            <h4><strong>SCHOENE FLORIST</strong></h4>
          </a>
          <div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
            <i class="ti ti-x fs-8"></i>
          </div>
        </div>
        @include('tempadmin.navbar')
      </div>
    </aside>
    <div class="body-wrapper">
      @include('tempadmin.header')
      @yield('container')
    </div>
  </div>
  <script src="/assets/libs/jquery/dist/jquery.min.js"></script>
  <script src="/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="/assets/js/sidebarmenu.js"></script>
  <script src="/assets/js/app.min.js"></script>
  <script src="/assets/libs/apexcharts/dist/apexcharts.min.js"></script>
  <script src="/assets/libs/simplebar/dist/simplebar.js"></script>
  <script src="/assets/js/dashboard.js"></script>

  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
  <script>
    new DataTable('#example');
  </script>
  <script src="https://code.highcharts.com/highcharts.js"></script>

  @if(isset($chart))  
  <script>
    Highcharts.chart('dashboard', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Data Grafik Peramalan / Forecasting untuk keseluruhan data pada Toko Buket SCHOENE FLORIST',
        align: 'center'
    },
    xAxis: {
        categories: {!!json_encode($arrTahun)!!},
        crosshair: true,
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Jumlah keseluruhan buket yang terjual'
        }
    },
    tooltip: {
        valueSuffix: ' Buket'
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [
        {
            name: 'Aktual',
            data: {!!json_encode($arrAktual)!!}
        },
        {
            name: 'Prediksi',
            data: {!!json_encode($arrPrediksi)!!}
        }
    ]

});

  </script>
  @elseif(isset($datahasil))  
  <script>
    Highcharts.chart('dashboard', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Data Grafik Peramalan / Forecasting untuk keseluruhan data pada Toko Buket SCHOENE FLORIST',
        align: 'center'
    },
    xAxis: {
        categories: {!!json_encode($arrTahun)!!},
        crosshair: true,
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Jumlah keseluruhan buket yang terjual'
        }
    },
    tooltip: {
        valueSuffix: ' Buket'
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [
        {
            name: 'Aktual',
            data: {!!json_encode($arrAktual)!!}
        },
        {
            name: 'Prediksi',
            data: {!!json_encode($arrPrediksi)!!}
        }
    ]

});

  </script>
  <!---grafik untuk data balon-->
  <script>
    Highcharts.chart('balon', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Data Grafik Peramalan / Forecasting untuk Buket Balon',
        align: 'center'
    },
    xAxis: {
        categories: {!!json_encode($arrTahunbalon)!!},
        crosshair: true,
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Jumlah keseluruhan buket yang terjual'
        }
    },
    tooltip: {
        valueSuffix: ' Buket'
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [
        {
            name: 'Aktual',
            data: {!!json_encode($arrAktualbalon)!!}
        },
        {
            name: 'Prediksi',
            data: {!!json_encode($arrPrediksibalon)!!}
        }
    ]
  
});

  </script>

  <!---grafik untuk data boneka-->
  <script>
    Highcharts.chart('boneka', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Data Grafik Peramalan / Forecasting untuk Buket Boneka',
        align: 'center'
    },
    xAxis: {
        categories: {!!json_encode($arrTahunboneka)!!},
        crosshair: true,
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Jumlah keseluruhan buket yang terjual'
        }
    },
    tooltip: {
        valueSuffix: ' Buket'
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [
        {
            name: 'Aktual',
            data: {!!json_encode($arrAktualboneka)!!}
        },
        {
            name: 'Prediksi',
            data: {!!json_encode($arrPrediksiboneka)!!}
        }
    ]
  
});

  </script>

  <!---grafik untuk data bunga-->
  <script>
    Highcharts.chart('bunga', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Data Grafik Peramalan / Forecasting untuk Buket Bunga',
        align: 'center'
    },
    xAxis: {
        categories: {!!json_encode($arrTahunbunga)!!},
        crosshair: true,
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Jumlah keseluruhan buket yang terjual'
        }
    },
    tooltip: {
        valueSuffix: ' Buket'
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [
        {
            name: 'Aktual',
            data: {!!json_encode($arrAktualbunga)!!}
        },
        {
            name: 'Prediksi',
            data: {!!json_encode($arrPrediksibunga)!!}
        }
    ]
  
});

  </script>

  <!---grafik untuk data snack-->
  <script>
    Highcharts.chart('snack', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Data Grafik Peramalan / Forecasting untuk Buket Snack',
        align: 'center'
    },
    xAxis: {
        categories: {!!json_encode($arrTahunsnack)!!},
        crosshair: true,
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Jumlah keseluruhan buket yang terjual'
        }
    },
    tooltip: {
        valueSuffix: ' Buket'
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [
        {
            name: 'Aktual',
            data: {!!json_encode($arrAktualsnack)!!}
        },
        {
            name: 'Prediksi',
            data: {!!json_encode($arrPrediksisnack)!!}
        }
    ]
  
});

  </script>

  <!---grafik untuk data uang-->
  <script>
    Highcharts.chart('uang', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Data Grafik Peramalan / Forecasting untuk Buket Uang',
        align: 'center'
    },
    xAxis: {
        categories: {!!json_encode($arrTahunuang)!!},
        crosshair: true,
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Jumlah keseluruhan buket yang terjual'
        }
    },
    tooltip: {
        valueSuffix: ' Buket'
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [
        {
            name: 'Aktual',
            data: {!!json_encode($arrAktualuang)!!}
        },
        {
            name: 'Prediksi',
            data: {!!json_encode($arrPrediksiuang)!!}
        }
    ]
  
});

  </script>
  @endif
</body>
</html>