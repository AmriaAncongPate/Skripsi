@extends('tempadmin.main')
@section('container')
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            @if(Session::has('buket'))
            {!!Session::get('buket')!!}
            @endif
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{$title}}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Buket</th>
                                    <th>Action</th>                                    
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($buket as $bkt)
                                <tr>
                                    <td>{{$nodf++}}</td>
                                    <td>{{$bkt->buket}}</td>
                                    <td>
                                      <a href="/edtbuket/{{$bkt->id}}" class="btn btn-primary">Edit</a>
                                    </td>                                    
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </dov>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
@endsection
