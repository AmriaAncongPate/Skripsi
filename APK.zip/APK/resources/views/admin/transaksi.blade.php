@extends('tempadmin.main')
@section('container')
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            @if(Session::has('transaksi'))
            {!!Session::get('transaksi')!!}
            @endif
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">{{$title}}</h2>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Bulan</th>
                                    <th>Tahun</th>
                                    <th>B. Balon</th>
                                    <th>B. Boneka</th>
                                    <th>B. Bunga</th>
                                    <th>B. Snack</th>
                                    <th>B. Uang</th>
                                    <th>Total</th>
                                    <th>Action</th>                                    
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($penjualan as $pjl)
                                <tr>
                                    <td>{{$nodf++}}</td>
                                    <td>{{$pjl->bulan->bulan}}</td>
                                    <td>{{$pjl->tahun->tahun}}</td>
                                    <td>{{$pjl->balon}}</td>
                                    <td>{{$pjl->boneka}}</td>
                                    <td>{{$pjl->bunga}}</td>
                                    <td>{{$pjl->snack}}</td>
                                    <td>{{$pjl->uang}}</td>
                                    <td>{{$pjl->total}}</td>
                                    <td>
                                      <a href="/edtransaksi/{{$pjl->id}}" class="btn btn-primary">Edit</a>
                                      <a href="/deltransaksi/{{$pjl->id}}" class="btn btn-danger" onclick="return confirm('Hapus Data Transaksi...?')">Delete</a>
                                    </td>                                    
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center">
                      <a href="/addtransaksi" class="btn btn-large btn-primary">Tambah Transaksi</a>
                    </div>
                </div>
            </div>
        </dov>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
@endsection
