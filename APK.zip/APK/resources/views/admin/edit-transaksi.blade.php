@extends('tempadmin.main')
@section('container')
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            @if(Session::has('transaksi'))
            {!!Session::get('transaksi')!!}
            @endif
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{$title}}</h4>
                </div>
                <div class="card-body">
                    <form action="/updatetrn" method="post">
                    @csrf
                    <input type="hidden" name="penjualan_id" value="{{$penjualan->id}}">
                    <div class="mb-3">
                        <label for="bulan_id" class="form-label">Bulan</label>
                        <select id="bulan_id" name="bulan_id" class="form-select" required>
                          @foreach($bulan as $bln)
                          @if($penjualan->bulan_id==$bln->id)
                          <option value="{{$bln->id}}" selected>{{$bln->bulan}}</option>
                          @else
                          <option value="{{$bln->id}}">{{$bln->bulan}}</option>
                          @endif
                          @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tahun_id" class="form-label">Tahun</label>
                        <select id="tahun_id" name="tahun_id" class="form-select" required>
                          @foreach($tahun as $thn)
                          @if($penjualan->tahun_id==$thn->id)
                          <option value="{{$thn->id}}" selected>{{$thn->tahun}}</option>
                          @else
                          <option value="{{$thn->id}}">{{$thn->tahun}}</option>
                          @endif
                          @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                      <label for="balon" class="form-label">Jumlah Buket Balon</label>
                      <input type="number" class="form-control" id="balon" name="balon" value="{{$penjualan->balon}}" required>
                    </div>
                    <div class="mb-3">
                      <label for="boneka" class="form-label">Jumlah Buket Boneka</label>
                      <input type="number" class="form-control" id="boneka" name="boneka" value="{{$penjualan->boneka}}" required>
                    </div>
                    <div class="mb-3">
                      <label for="bunga" class="form-label">Jumlah Buket Bunga</label>
                      <input type="number" class="form-control" id="bunga" name="bunga" value="{{$penjualan->bunga}}" required>
                    </div>
                    <div class="mb-3">
                      <label for="snack" class="form-label">Jumlah Buket Snack</label>
                      <input type="number" class="form-control" id="snack" name="snack" value="{{$penjualan->snack}}" required>
                    </div>
                    <div class="mb-3">
                      <label for="uang" class="form-label">Jumlah Buket Uang</label>
                      <input type="number" class="form-control" id="uang" name="uang" value="{{$penjualan->uang}}" required>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="/transaksi" class="btn btn-info">Kembali</a>
                    </div>
                  </form>
                </div>
            </div>
        </dov>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
@endsection
