<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('forecastingsnacks', function (Blueprint $table) {
            $table->id();
            $table->integer('tahun');
            $table->integer('snack');
            $table->float('smooth1');
            $table->float('smooth2');
            $table->float('konstanta');
            $table->float('slope');
            $table->float('forecasting');
            $table->float('error');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('forecastingsnacks');
    }
};
