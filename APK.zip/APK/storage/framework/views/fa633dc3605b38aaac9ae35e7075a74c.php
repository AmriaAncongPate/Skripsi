
<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            <?php if(Session::has('prshitung')): ?>
            <?php echo Session::get('prshitung'); ?>

            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($title); ?></h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Bulan</th>
                                    <th>Tahun</th>
                                    <th>B. Balon</th>
                                    <th>B. Boneka</th>
                                    <th>B. Bunga</th>
                                    <th>B. Snack</th>
                                    <th>B. Uang</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pjl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($nodf++); ?></td>
                                    <td><?php echo e($pjl->bulan->bulan); ?></td>
                                    <td><?php echo e($pjl->tahun->tahun); ?></td>
                                    <td><?php echo e($pjl->balon); ?></td>
                                    <td><?php echo e($pjl->boneka); ?></td>
                                    <td><?php echo e($pjl->bunga); ?></td>
                                    <td><?php echo e($pjl->snack); ?></td>
                                    <td><?php echo e($pjl->uang); ?></td>
                                    <td><?php echo e($pjl->total); ?></td>                             
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <form action="/mulaiprs" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                      <label for="alpa" class="form-label">Koefisien Pemulusan (Smoothing)</label>
                      <input type="number" class="form-control" id="alpa" step="any" name="alpa" placeholder="Masukkan nilai pemulusan" required>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Mulai Perhitungan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tempadmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amriapk\resources\views/admin/proses-hitung.blade.php ENDPATH**/ ?>