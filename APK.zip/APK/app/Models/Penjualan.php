<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Penjualan extends Model
{
    use HasFactory;

    protected $fillable = [

        'bulan_id',
        'tahun_id',
        'balon',
        'boneka',
        'bunga',
        'snack',
        'uang',
        'total',
    ];

    public function bulan()
    {
        return $this->belongsto(Bulan::class);
    }

    public function tahun()
    {
        return $this->belongsto(Tahun::class);
    }
}
