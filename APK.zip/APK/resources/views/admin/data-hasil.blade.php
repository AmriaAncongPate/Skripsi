@extends('tempadmin.main')
@section('container')
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            @if(Session::has('prshitung'))
            {!!Session::get('prshitung')!!}
            @endif
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Akumulasi Keseluruhan Data</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>B. Balon</th>
                                    <th>B. Boneka</th>
                                    <th>B. Bunga</th>
                                    <th>B. Snack</th>
                                    <th>B. Uang</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($pertahun as $thn)
                                <tr>
                                    <td>{{$nodf++}}</td>
                                    <td>{{$thn->tahun->tahun}}</td>
                                    <td>{{$thn->balon}}</td>
                                    <td>{{$thn->boneka}}</td>
                                    <td>{{$thn->bunga}}</td>
                                    <td>{{$thn->snack}}</td>
                                    <td>{{$thn->uang}}</td>
                                    <td>{{$thn->total}}</td>                             
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <hr>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Buket Balon dengan nilai Smoothing : {{$alfa->alfa}}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($balon as $bln)
                                <tr>
                                    <td>{{$dbalon++}}</td>
                                    <td>{{$bln->tahun}}</td>
                                    <td>{{$bln->balon}}</td>
                                    <td>{{$bln->smooth1}}</td>
                                    <td>{{$bln->smooth2}}</td>
                                    <td>{{$bln->konstanta}}</td>
                                    <td>{{$bln->slope}}</td>
                                    <td>{{$bln->forecasting}}</td>
                                    <td>{{$bln->error}}</td>                             
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @if($mpbalon->mape==null)
                    <h3>Nilai MAPE Balon Belum dihitung</h3>
                    @else
                        <h3>Nilai MAPE = {{$mpbalon->mape}}&nbsp;
                        @if($mpbalon->mape<=10)
                        (Hasil Peramalan Sangat Akurat)
                        @elseif($mpbalon->mape>10 && $mpbalon->mape<=20)
                        (Hasil Peramalan Baik)
                        @elseif($mpbalon->mape>20 && $mpbalon->mape<=50)
                        (Hasil Peramalan Layak / Cukup)
                        @else
                        (Hasil Peramalan Tidak Akurat)
                        @endif
                        </h3>
                        <h3>Prediksi penjualan buket Balon untuk tahun depan ({{date('Y')+1}}) yaitu: {{round($ltbalon->konstanta+($ltbalon->slope*1))}}</h3>
                    @endif
                </div>
            </div>
            <div class="card">
                <div id="balon"></div>
            </div>
            <hr>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Buket Boneka dengan nilai Smoothing : {{$alfa->alfa}}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($boneka as $bln)
                                <tr>
                                    <td>{{$dboneka++}}</td>
                                    <td>{{$bln->tahun}}</td>
                                    <td>{{$bln->boneka}}</td>
                                    <td>{{$bln->smooth1}}</td>
                                    <td>{{$bln->smooth2}}</td>
                                    <td>{{$bln->konstanta}}</td>
                                    <td>{{$bln->slope}}</td>
                                    <td>{{$bln->forecasting}}</td>
                                    <td>{{$bln->error}}</td>                             
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @if($mpboneka->mape==null)
                    <h3>Nilai MAPE Boneka Belum dihitung</h3>
                    @else
                        <h3>Nilai MAPE = {{$mpboneka->mape}}&nbsp;
                        @if($mpbalon->mape<=10)
                        (Hasil Peramalan Sangat Akurat)
                        @elseif($mpboneka->mape>10 && $mpboneka->mape<=20)
                        (Hasil Peramalan Baik)
                        @elseif($mpboneka->mape>20 && $mpboneka->mape<=50)
                        (Hasil Peramalan Layak / Cukup)
                        @else
                        (Hasil Peramalan Tidak Akurat)
                        @endif
                        </h3>
                        <h3>Prediksi penjualan buket Boneka untuk tahun depan ({{date('Y')+1}}) yaitu: {{round($ltboneka->konstanta+($ltboneka->slope*1))}}</h3>
                    @endif
                </div>
            </div>
            <div class="card">
                <div id="boneka"></div>
            </div>
            <hr>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Buket Bunga dengan nilai Smoothing : {{$alfa->alfa}}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($bunga as $bln)
                                <tr>
                                    <td>{{$dbunga++}}</td>
                                    <td>{{$bln->tahun}}</td>
                                    <td>{{$bln->bunga}}</td>
                                    <td>{{$bln->smooth1}}</td>
                                    <td>{{$bln->smooth2}}</td>
                                    <td>{{$bln->konstanta}}</td>
                                    <td>{{$bln->slope}}</td>
                                    <td>{{$bln->forecasting}}</td>
                                    <td>{{$bln->error}}</td>                             
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @if($mpbunga->mape==null)
                    <h3>Nilai MAPE Bunga Belum dihitung</h3>
                    @else
                        <h3>Nilai MAPE = {{$mpbunga->mape}}&nbsp;
                        @if($mpbunga->mape<=10)
                        (Hasil Peramalan Sangat Akurat)
                        @elseif($mpbunga->mape>10 && $mpbunga->mape<=20)
                        (Hasil Peramalan Baik)
                        @elseif($mpbunga->mape>20 && $mpbunga->mape<=50)
                        (Hasil Peramalan Layak / Cukup)
                        @else
                        (Hasil Peramalan Tidak Akurat)
                        @endif
                        </h3>
                        <h3>Prediksi penjualan buket Bunga untuk tahun depan ({{date('Y')+1}}) yaitu: {{round($ltbunga->konstanta+($ltbunga->slope*1))}}</h3>
                    @endif
                </div>
            </div>
            <div class="card">
                <div id="bunga"></div>
            </div>
            <hr>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Buket Snack dengan nilai Smoothing : {{$alfa->alfa}}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($snack as $bln)
                                <tr>
                                    <td>{{$dsnack++}}</td>
                                    <td>{{$bln->tahun}}</td>
                                    <td>{{$bln->snack}}</td>
                                    <td>{{$bln->smooth1}}</td>
                                    <td>{{$bln->smooth2}}</td>
                                    <td>{{$bln->konstanta}}</td>
                                    <td>{{$bln->slope}}</td>
                                    <td>{{$bln->forecasting}}</td>
                                    <td>{{$bln->error}}</td>                             
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @if($mpsnack->mape==null)
                    <h3>Nilai MAPE Snack Belum dihitung</h3>
                    @else
                        <h3>Nilai MAPE = {{$mpsnack->mape}}&nbsp;
                        @if($mpsnack->mape<=10)
                        (Hasil Peramalan Sangat Akurat)
                        @elseif($mpsnack->mape>10 && $mpsnack->mape<=20)
                        (Hasil Peramalan Baik)
                        @elseif($mpsnack->mape>20 && $mpsnack->mape<=50)
                        (Hasil Peramalan Layak / Cukup)
                        @else
                        (Hasil Peramalan Tidak Akurat)
                        @endif
                        </h3>
                        <h3>Prediksi penjualan buket Snack untuk tahun depan ({{date('Y')+1}}) yaitu: {{round($ltsnack->konstanta+($ltsnack->slope*1))}}</h3>
                    @endif
                </div>
            </div>
            <div class="card">
                <div id="snack"></div>
            </div>
            <hr>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Buket Uang dengan nilai Smoothing : {{$alfa->alfa}}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($uang as $bln)
                                <tr>
                                    <td>{{$duang++}}</td>
                                    <td>{{$bln->tahun}}</td>
                                    <td>{{$bln->uang}}</td>
                                    <td>{{$bln->smooth1}}</td>
                                    <td>{{$bln->smooth2}}</td>
                                    <td>{{$bln->konstanta}}</td>
                                    <td>{{$bln->slope}}</td>
                                    <td>{{$bln->forecasting}}</td>
                                    <td>{{$bln->error}}</td>                             
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @if($mpuang->mape==null)
                    <h3>Nilai MAPE Uang Belum dihitung</h3>
                    @else
                        <h3>Nilai MAPE = {{$mpuang->mape}}&nbsp;
                        @if($mpuang->mape<=10)
                        (Hasil Peramalan Sangat Akurat)
                        @elseif($mpuang->mape>10 && $mpuang->mape<=20)
                        (Hasil Peramalan Baik)
                        @elseif($mpuang->mape>20 && $mpuang->mape<=50)
                        (Hasil Peramalan Layak / Cukup)
                        @else
                        (Hasil Peramalan Tidak Akurat)
                        @endif
                        </h3>
                        <h3>Prediksi penjualan buket Uang untuk tahun depan ({{date('Y')+1}}) yaitu: {{round($ltuang->konstanta+($ltuang->slope*1))}}</h3>
                    @endif
                </div>
            </div>
            <div class="card">
                <div id="uang"></div>
            </div>
            <hr>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Total Seluruh Buket dengan nilai Smoothing : {{$alfa->alfa}}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($total as $bln)
                                <tr>
                                    <td>{{$dtotal++}}</td>
                                    <td>{{$bln->tahun}}</td>
                                    <td>{{$bln->total}}</td>
                                    <td>{{$bln->smooth1}}</td>
                                    <td>{{$bln->smooth2}}</td>
                                    <td>{{$bln->konstanta}}</td>
                                    <td>{{$bln->slope}}</td>
                                    <td>{{$bln->forecasting}}</td>
                                    <td>{{$bln->error}}</td>                             
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @if($mptotal->mape==null)
                    <h3>Nilai MAPE Total Belum dihitung</h3>
                    @else
                        <h3>Nilai MAPE = {{$mptotal->mape}}&nbsp;
                        @if($mptotal->mape<=10)
                        (Hasil Peramalan Sangat Akurat)
                        @elseif($mptotal->mape>10 && $mptotal->mape<=20)
                        (Hasil Peramalan Baik)
                        @elseif($mptotal->mape>20 && $mptotal->mape<=50)
                        (Hasil Peramalan Layak / Cukup)
                        @else
                        (Hasil Peramalan Tidak Akurat)
                        @endif
                        </h3>
                        <h3>Prediksi penjualan untuk keseluruhan buket tahun depan ({{date('Y')+1}}) yaitu: {{round($lttotal->konstanta+($lttotal->slope*1))}}</h3>
                    @endif
                </div>
            </div>
            <div class="card">
                <div id="dashboard"></div>
            </div>
        </div>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
@endsection
