@extends('tempadmin.main')
@section('container')
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            @if(Session::has('buket'))
            {!!Session::get('buket')!!}
            @endif
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{$title}}</h4>
                </div>
                <div class="card-body">
                    <form action="/updatebkt" method="post">
                    @csrf
                    <input type="hidden" name="buket_id" value="{{$buket->id}}">
                    <div class="mb-3">
                      <label for="buket" class="form-label">Nama Buket</label>
                      <input type="text" class="form-control" id="buket" name="buket" value="{{$buket->buket}}">
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="/buket" class="btn btn-info">Kembali</a>
                    </div>
                  </form>
                </div>
            </div>
        </dov>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
@endsection
