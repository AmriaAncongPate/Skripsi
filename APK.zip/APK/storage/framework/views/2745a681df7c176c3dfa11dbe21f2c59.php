
<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            <?php if(Session::has('buket')): ?>
            <?php echo Session::get('buket'); ?>

            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($title); ?></h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Buket</th>
                                    <th>Action</th>                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $buket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bkt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($nodf++); ?></td>
                                    <td><?php echo e($bkt->buket); ?></td>
                                    <td>
                                      <a href="/edtbuket/<?php echo e($bkt->id); ?>" class="btn btn-primary">Edit</a>
                                    </td>                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </dov>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tempadmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amriapk\resources\views/admin/buket.blade.php ENDPATH**/ ?>