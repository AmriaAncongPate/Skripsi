
<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row mb-4">
      <h1 class="text-center"><strong>SELAMAT DATANG DI APLIKASI ANALISIS METODE DOUBLE EXPONENTIAL SMOOTHING UNTUK PREDIKSI PENJUALAN BUKET PADA TOKO SCHOENE FLORIST</strong></h1>
    </div>
    <div class="row">
      <div class="col-md-4 d-flex align-items-strech">
                  <div class="card">
                    <div class="card-body">
                      <h5 class="card-title">Data Buket</h5>
                      <p class="card-text"><?php echo e($buket); ?></p>
                      <a href="/buket" class="btn btn-primary">Lihat Data</a>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 d-flex align-items-strech">
                  <div class="card">
                    <div class="card-body">
                      <h5 class="card-title">Data Transaksi</h5>
                      <p class="card-text"><?php echo e($penjualan); ?></p>
                      <a href="/transaksi" class="btn btn-primary">Lihat Data</a>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 d-flex align-items-strech">
                  <div class="card">
                    <div class="card-body">
                      <h5 class="card-title">Data Hasil</h5>
                      <p class="card-text"><?php echo e($pertahun); ?></p>
                      <a href="/hasil" class="btn btn-primary">Lihat Data</a>
                    </div>
                  </div>
                </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Akumulasi Keseluruhan Data</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>B. Balon</th>
                                    <th>B. Boneka</th>
                                    <th>B. Bunga</th>
                                    <th>B. Snack</th>
                                    <th>B. Uang</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dtpertahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($nodf++); ?></td>
                                    <td><?php echo e($thn->tahun->tahun); ?></td>
                                    <td><?php echo e($thn->balon); ?></td>
                                    <td><?php echo e($thn->boneka); ?></td>
                                    <td><?php echo e($thn->bunga); ?></td>
                                    <td><?php echo e($thn->snack); ?></td>
                                    <td><?php echo e($thn->uang); ?></td>
                                    <td><?php echo e($thn->total); ?></td>                             
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Total Seluruh Buket dengan nilai Smoothing : <?php echo e($alfa->alfa); ?></h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dtotal++); ?></td>
                                    <td><?php echo e($bln->tahun); ?></td>
                                    <td><?php echo e($bln->total); ?></td>
                                    <td><?php echo e($bln->smooth1); ?></td>
                                    <td><?php echo e($bln->smooth2); ?></td>
                                    <td><?php echo e($bln->konstanta); ?></td>
                                    <td><?php echo e($bln->slope); ?></td>
                                    <td><?php echo e($bln->forecasting); ?></td>
                                    <td><?php echo e($bln->error); ?></td>                             
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($mptotal->mape==null): ?>
                    <h3>Nilai MAPE Belum Dihitung</h3>
                    <?php else: ?>
                    <h3>Nilai MAPE = <?php echo e($mptotal->mape); ?>&nbsp;
                        <?php if($mptotal->mape<=10): ?>
                        (Hasil Peramalan Sangat Akurat)
                        <?php elseif($mptotal->mape>10 && $mptotal->mape<=20): ?>
                        (Hasil Peramalan Baik)
                        <?php elseif($mptotal->mape>20 && $mptotal->mape<=50): ?>
                        (Hasil Peramalan Layak / Cukup)
                        <?php else: ?>
                        (Hasil Peramalan Tidak Akurat)
                        <?php endif; ?>
                        </h3>
                    <h3>Prediksi penjualan untuk keseluruhan buket tahun depan (<?php echo e(date('Y')+1); ?>) yaitu: <?php echo e(round($lttotal->konstanta+($lttotal->slope*1))); ?></h3>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card">
                <div id="dashboard"></div>
            </div>
        </div>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tempadmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amriapk\resources\views/admin/index.blade.php ENDPATH**/ ?>