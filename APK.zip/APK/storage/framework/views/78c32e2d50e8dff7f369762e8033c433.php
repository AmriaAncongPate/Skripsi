
<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            <?php if(Session::has('transaksi')): ?>
            <?php echo Session::get('transaksi'); ?>

            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($title); ?></h4>
                </div>
                <div class="card-body">
                    <form action="/addtransaksi" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="bulan_id" class="form-label">Bulan</label>
                        <select id="bulan_id" name="bulan_id" class="form-select" required>
                          <option value="">Pilih Bulan</option>
                          <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($bln->id); ?>"><?php echo e($bln->bulan); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tahun_id" class="form-label">Tahun</label>
                        <select id="tahun_id" name="tahun_id" class="form-select" required>
                          <option value="">Pilih Tahun</option>
                          <?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($thn->id); ?>"><?php echo e($thn->tahun); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                      <label for="balon" class="form-label">Jumlah Buket Balon</label>
                      <input type="number" class="form-control" id="balon" name="balon" placeholder="Masukkan Jumlah terbeli balon" required>
                    </div>
                    <div class="mb-3">
                      <label for="boneka" class="form-label">Jumlah Buket Boneka</label>
                      <input type="number" class="form-control" id="boneka" name="boneka" placeholder="Masukkan Jumlah terbeli boneka" required> 
                    </div>
                    <div class="mb-3">
                      <label for="bunga" class="form-label">Jumlah Buket Bunga</label>
                      <input type="number" class="form-control" id="bunga" name="bunga" placeholder="Masukkan Jumlah terbeli bunga" required>
                    </div>
                    <div class="mb-3">
                      <label for="snack" class="form-label">Jumlah Buket Snack</label>
                      <input type="number" class="form-control" id="snack" name="snack" placeholder="Masukkan Jumlah terbeli snack" required>
                    </div>
                    <div class="mb-3">
                      <label for="uang" class="form-label">Jumlah Buket Uang</label>
                      <input type="number" class="form-control" id="uang" name="uang" placeholder="Masukkan Jumlah terbeli uang" required>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Tambah</button>
                        <a href="/transaksi" class="btn btn-info">Kembali</a>
                    </div>
                  </form>
                </div>
            </div>
        </dov>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tempadmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amriapk\resources\views/admin/add-transaksi.blade.php ENDPATH**/ ?>