
<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            <?php if(Session::has('transaksi')): ?>
            <?php echo Session::get('transaksi'); ?>

            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title"><?php echo e($title); ?></h2>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Bulan</th>
                                    <th>Tahun</th>
                                    <th>B. Balon</th>
                                    <th>B. Boneka</th>
                                    <th>B. Bunga</th>
                                    <th>B. Snack</th>
                                    <th>B. Uang</th>
                                    <th>Total</th>
                                    <th>Action</th>                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pjl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($nodf++); ?></td>
                                    <td><?php echo e($pjl->bulan->bulan); ?></td>
                                    <td><?php echo e($pjl->tahun->tahun); ?></td>
                                    <td><?php echo e($pjl->balon); ?></td>
                                    <td><?php echo e($pjl->boneka); ?></td>
                                    <td><?php echo e($pjl->bunga); ?></td>
                                    <td><?php echo e($pjl->snack); ?></td>
                                    <td><?php echo e($pjl->uang); ?></td>
                                    <td><?php echo e($pjl->total); ?></td>
                                    <td>
                                      <a href="/edtransaksi/<?php echo e($pjl->id); ?>" class="btn btn-primary">Edit</a>
                                      <a href="/deltransaksi/<?php echo e($pjl->id); ?>" class="btn btn-danger" onclick="return confirm('Hapus Data Transaksi...?')">Delete</a>
                                    </td>                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center">
                      <a href="/addtransaksi" class="btn btn-large btn-primary">Tambah Transaksi</a>
                    </div>
                </div>
            </div>
        </dov>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tempadmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amriapk\resources\views/admin/transaksi.blade.php ENDPATH**/ ?>