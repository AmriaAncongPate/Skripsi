
<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            <?php if(Session::has('prshitung')): ?>
            <?php echo Session::get('prshitung'); ?>

            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Akumulasi Keseluruhan Data</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>B. Balon</th>
                                    <th>B. Boneka</th>
                                    <th>B. Bunga</th>
                                    <th>B. Snack</th>
                                    <th>B. Uang</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pertahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($nodf++); ?></td>
                                    <td><?php echo e($thn->tahun->tahun); ?></td>
                                    <td><?php echo e($thn->balon); ?></td>
                                    <td><?php echo e($thn->boneka); ?></td>
                                    <td><?php echo e($thn->bunga); ?></td>
                                    <td><?php echo e($thn->snack); ?></td>
                                    <td><?php echo e($thn->uang); ?></td>
                                    <td><?php echo e($thn->total); ?></td>                             
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Buket Balon dengan nilai Smoothing : <?php echo e($alfa->alfa); ?></h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $balon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dbalon++); ?></td>
                                    <td><?php echo e($bln->tahun); ?></td>
                                    <td><?php echo e($bln->balon); ?></td>
                                    <td><?php echo e($bln->smooth1); ?></td>
                                    <td><?php echo e($bln->smooth2); ?></td>
                                    <td><?php echo e($bln->konstanta); ?></td>
                                    <td><?php echo e($bln->slope); ?></td>
                                    <td><?php echo e($bln->forecasting); ?></td>
                                    <td><?php echo e($bln->error); ?></td>                             
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <h3>Nilai MAPE = <?php echo e($mpbalon->mape); ?>&nbsp;
                    <?php if($mpbalon->mape<=10): ?>
                    (Hasil Peramalan Sangat Akurat)
                    <?php elseif($mpbalon->mape>10 && $mpbalon->mape<=20): ?>
                    (Hasil Peramalan Baik)
                    <?php elseif($mpbalon->mape>20 && $mpbalon->mape<=50): ?>
                    (Hasil Peramalan Layak / Cukup)
                    <?php else: ?>
                    (Hasil Peramalan Tidak Akurat)
                    <?php endif; ?>
                    </h3>
                    <h3>Prediksi penjualan buket Balon untuk tahun depan (<?php echo e(date('Y')+1); ?>) yaitu: <?php echo e(round($ltbalon->konstanta+($ltbalon->slope*1))); ?></h3>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Buket Boneka dengan nilai Smoothing : <?php echo e($alfa->alfa); ?></h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $boneka; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dboneka++); ?></td>
                                    <td><?php echo e($bln->tahun); ?></td>
                                    <td><?php echo e($bln->boneka); ?></td>
                                    <td><?php echo e($bln->smooth1); ?></td>
                                    <td><?php echo e($bln->smooth2); ?></td>
                                    <td><?php echo e($bln->konstanta); ?></td>
                                    <td><?php echo e($bln->slope); ?></td>
                                    <td><?php echo e($bln->forecasting); ?></td>
                                    <td><?php echo e($bln->error); ?></td>                             
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <h3>Nilai MAPE = <?php echo e($mpboneka->mape); ?>&nbsp;
                    <?php if($mpbalon->mape<=10): ?>
                    (Hasil Peramalan Sangat Akurat)
                    <?php elseif($mpboneka->mape>10 && $mpboneka->mape<=20): ?>
                    (Hasil Peramalan Baik)
                    <?php elseif($mpboneka->mape>20 && $mpboneka->mape<=50): ?>
                    (Hasil Peramalan Layak / Cukup)
                    <?php else: ?>
                    (Hasil Peramalan Tidak Akurat)
                    <?php endif; ?>
                    </h3>
                    <h3>Prediksi penjualan buket Boneka untuk tahun depan (<?php echo e(date('Y')+1); ?>) yaitu: <?php echo e(round($ltboneka->konstanta+($ltboneka->slope*1))); ?></h3>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Buket Bunga dengan nilai Smoothing : <?php echo e($alfa->alfa); ?></h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $bunga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dbunga++); ?></td>
                                    <td><?php echo e($bln->tahun); ?></td>
                                    <td><?php echo e($bln->bunga); ?></td>
                                    <td><?php echo e($bln->smooth1); ?></td>
                                    <td><?php echo e($bln->smooth2); ?></td>
                                    <td><?php echo e($bln->konstanta); ?></td>
                                    <td><?php echo e($bln->slope); ?></td>
                                    <td><?php echo e($bln->forecasting); ?></td>
                                    <td><?php echo e($bln->error); ?></td>                             
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <h3>Nilai MAPE = <?php echo e($mpbunga->mape); ?>&nbsp;
                    <?php if($mpbunga->mape<=10): ?>
                    (Hasil Peramalan Sangat Akurat)
                    <?php elseif($mpbunga->mape>10 && $mpbunga->mape<=20): ?>
                    (Hasil Peramalan Baik)
                    <?php elseif($mpbunga->mape>20 && $mpbunga->mape<=50): ?>
                    (Hasil Peramalan Layak / Cukup)
                    <?php else: ?>
                    (Hasil Peramalan Tidak Akurat)
                    <?php endif; ?>
                    </h3>
                    <h3>Prediksi penjualan buket Bunga untuk tahun depan (<?php echo e(date('Y')+1); ?>) yaitu: <?php echo e(round($ltbunga->konstanta+($ltbunga->slope*1))); ?></h3>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Buket Snack dengan nilai Smoothing : <?php echo e($alfa->alfa); ?></h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $snack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dsnack++); ?></td>
                                    <td><?php echo e($bln->tahun); ?></td>
                                    <td><?php echo e($bln->snack); ?></td>
                                    <td><?php echo e($bln->smooth1); ?></td>
                                    <td><?php echo e($bln->smooth2); ?></td>
                                    <td><?php echo e($bln->konstanta); ?></td>
                                    <td><?php echo e($bln->slope); ?></td>
                                    <td><?php echo e($bln->forecasting); ?></td>
                                    <td><?php echo e($bln->error); ?></td>                             
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <h3>Nilai MAPE = <?php echo e($mpsnack->mape); ?>&nbsp;
                    <?php if($mpsnack->mape<=10): ?>
                    (Hasil Peramalan Sangat Akurat)
                    <?php elseif($mpsnack->mape>10 && $mpsnack->mape<=20): ?>
                    (Hasil Peramalan Baik)
                    <?php elseif($mpsnack->mape>20 && $mpsnack->mape<=50): ?>
                    (Hasil Peramalan Layak / Cukup)
                    <?php else: ?>
                    (Hasil Peramalan Tidak Akurat)
                    <?php endif; ?>
                    </h3>
                    <h3>Prediksi penjualan buket Snack untuk tahun depan (<?php echo e(date('Y')+1); ?>) yaitu: <?php echo e(round($ltsnack->konstanta+($ltsnack->slope*1))); ?></h3>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Buket Uang dengan nilai Smoothing : <?php echo e($alfa->alfa); ?></h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $uang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($duang++); ?></td>
                                    <td><?php echo e($bln->tahun); ?></td>
                                    <td><?php echo e($bln->uang); ?></td>
                                    <td><?php echo e($bln->smooth1); ?></td>
                                    <td><?php echo e($bln->smooth2); ?></td>
                                    <td><?php echo e($bln->konstanta); ?></td>
                                    <td><?php echo e($bln->slope); ?></td>
                                    <td><?php echo e($bln->forecasting); ?></td>
                                    <td><?php echo e($bln->error); ?></td>                             
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <h3>Nilai MAPE = <?php echo e($mpuang->mape); ?>&nbsp;
                    <?php if($mpuang->mape<=10): ?>
                    (Hasil Peramalan Sangat Akurat)
                    <?php elseif($mpuang->mape>10 && $mpuang->mape<=20): ?>
                    (Hasil Peramalan Baik)
                    <?php elseif($mpuang->mape>20 && $mpuang->mape<=50): ?>
                    (Hasil Peramalan Layak / Cukup)
                    <?php else: ?>
                    (Hasil Peramalan Tidak Akurat)
                    <?php endif; ?>
                    </h3>
                    <h3>Prediksi penjualan buket Uang untuk tahun depan (<?php echo e(date('Y')+1); ?>) yaitu: <?php echo e(round($ltuang->konstanta+($ltuang->slope*1))); ?></h3>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Hasil Perhitungan Forecasting / Peramalan pada Total Seluruh Buket dengan nilai Smoothing : <?php echo e($alfa->alfa); ?></h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tahun</th>
                                    <th>Data Aktual</th>
                                    <th><em>S<sup>'</sup></em></th>
                                    <th><em>S<sup>''</sup></em></th>
                                    <th><em>at</em></th>
                                    <th><em>bt</em></th>
                                    <th>Forecasting</th>
                                    <th>Absolut Error</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dtotal++); ?></td>
                                    <td><?php echo e($bln->tahun); ?></td>
                                    <td><?php echo e($bln->total); ?></td>
                                    <td><?php echo e($bln->smooth1); ?></td>
                                    <td><?php echo e($bln->smooth2); ?></td>
                                    <td><?php echo e($bln->konstanta); ?></td>
                                    <td><?php echo e($bln->slope); ?></td>
                                    <td><?php echo e($bln->forecasting); ?></td>
                                    <td><?php echo e($bln->error); ?></td>                             
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <h3>Nilai MAPE = <?php echo e($mptotal->mape); ?>&nbsp;
                    <?php if($mptotal->mape<=10): ?>
                    (Hasil Peramalan Sangat Akurat)
                    <?php elseif($mptotal->mape>10 && $mptotal->mape<=20): ?>
                    (Hasil Peramalan Baik)
                    <?php elseif($mptotal->mape>20 && $mptotal->mape<=50): ?>
                    (Hasil Peramalan Layak / Cukup)
                    <?php else: ?>
                    (Hasil Peramalan Tidak Akurat)
                    <?php endif; ?>
                    </h3>
                    <h3>Prediksi penjualan keseluruhan Buket untuk tahun depan (<?php echo e(date('Y')+1); ?>) yaitu: <?php echo e(round($lttotal->konstanta+($lttotal->slope*1))); ?></h3>
                </div>
            </div>
        </div>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tempadmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amriapk\resources\views/admin/hasil-hitung.blade.php ENDPATH**/ ?>