<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

//call model
use App\Models\Alfa;
use App\Models\Buket;
use App\Models\Bulan;
use App\Models\Tahun;
use App\Models\Penjualan;
use App\Models\Dtpertahun;

use App\Models\Forecastingtotal;
use App\Models\Forecastingbalon;
use App\Models\Forecastingboneka;
use App\Models\Forecastingbunga;
use App\Models\Forecastingsnack;
use App\Models\Forecastinguang;
use App\Models\Mape;

class AdminController extends Controller
{

    //function untuk menampilkan halaman dashboard
    public function index()
    {
        //mengambil forecasting total keseluruhan
        $getTotal = Forecastingtotal::all();

        $arrTahun = [];
        $arrAktual = [];
        $arrPrediksi = [];

        $limiter = count($getTotal)-1;

        for ($i=0; $i <= $limiter; $i++) { 

            $arrTahun[] = $getTotal[$i]->tahun;
            $arrAktual[] = $getTotal[$i]->total;
            $arrPrediksi[] = round($getTotal[$i]->forecasting);
        }

        $getEndTotal = Forecastingtotal::latest()->first();

        $arrTahun[] = $getEndTotal->tahun+1;
        $arrPrediksi[] = round($getEndTotal->konstanta+($getEndTotal->slope*1));

        return view('admin.index',[

            'title' => 'Dashboard',
            'chart' => 'dashboard',
            'buket' => Buket::count(),
            'penjualan' => Penjualan::count(),
            'pertahun' => Dtpertahun::count(),
            'dtpertahun' => Dtpertahun::get(),
            'nodf' => 1,

            'arrTahun' => $arrTahun,
            'arrAktual' => $arrAktual,
            'arrPrediksi' => $arrPrediksi,
            'alfa' => Alfa::latest()->first(),
            'total' => Forecastingtotal::get(),
            'lttotal' => Forecastingtotal::latest()->first(),
            'mptotal' => Mape::where('keterangan','Keseluruhan')->first(),
            'dtotal' => 1,
        ]);
    }

    //function untuk menampilkan halaman data buket
    public function buket()
    {
        return view('admin.buket',[

            'title' => 'Data Buket',
            'nodf' => 1,
            'buket' => Buket::orderBy('buket','asc')->get(),
        ]);
    }

    //function untuk menampilkan halaman edit buket
    public function edtbuket(Buket $buket)
    {
        return view('admin.edit-buket',[

            'title' => 'Edit Buket',
            'buket' => $buket,
        ]);
    }

    //function untuk melakukan proses edit buket
    public function updatebkt(Request $request)
    {
        $validasiData = $request->validate([

            'buket' => 'required',
        ]);

        Buket::where('id',$request->buket_id)->update($validasiData);
        return redirect('buket')->with('buket','<div class="alert alert-success text-center" role="alert">Nama Buket Berhasil diperbarui...!</div>');
    }

    //function untuk menampilkan halaman data transaksi
    public function transaksi()
    {
        return view('admin.transaksi',[

            'title' => 'Data Transaksi Buket',
            'penjualan' => Penjualan::orderBy('tahun_id','asc')->orderBy('bulan_id','asc')->get(),
            'nodf' => 1,
        ]);
    }

    //function untuk menampilkan halaman tambah data transaksi
    public function addtransaksi(Request $request)
    {
        if ($request->isMethod('post')) {
            
            $validasiData = $request->validate([

                'bulan_id' => 'required',
                'tahun_id' => 'required',
                'balon' => 'required',
                'boneka' => 'required',
                'bunga' => 'required',
                'snack' => 'required',
                'uang' => 'required',
            ]);

            $validasiData['total'] = $request->balon+$request->boneka+$request->bunga+$request->snack+$request->uang;

            Penjualan::create($validasiData);
            return redirect('transaksi')->with('transaksi','<div class="alert alert-success text-center" role="alert">Data Transaksi Berhasil ditambahkan...!</div>');
        }

        return view('admin.add-transaksi',[

            'title' => 'Tambah Data Transaksi',
            'bulan' => Bulan::get(),
            'tahun' => Tahun::get(),
            'buket' => Buket::orderBy('buket','asc')->get(),
        ]);
    }

    //function untuk menampilkan halaman edit data transaksi
    public function edtransaksi(Penjualan $penjualan)
    {
        return view('admin.edit-transaksi',[

            'title' => 'Edit Data Transaksi',
            'penjualan' => $penjualan,
            'bulan' => Bulan::get(),
            'tahun' => Tahun::get(),
        ]);
    }

    //function untuk melakukan proses update data transaksi
    public function updatetrn(Request $request)
    {
        $validasiData = $request->validate([

            'bulan_id' => 'required',
            'tahun_id' => 'required',
            'balon' => 'required',
            'boneka' => 'required',
            'bunga' => 'required',
            'snack' => 'required',
            'uang' => 'required',
        ]);

        $validasiData['total'] = $request->balon+$request->boneka+$request->bunga+$request->snack+$request->uang;

        Penjualan::where('id',$request->penjualan_id)->update($validasiData);
        return redirect('transaksi')->with('transaksi','<div class="alert alert-success text-center" role="alert">Data Transaksi Berhasil diperbarui...!</div>');
    }

    //function untuk menghapus data transaksi
    public function deltransaksi(Penjualan $penjualan)
    {
        $penjualan->delete();
        return redirect('transaksi')->with('transaksi','<div class="alert alert-danger text-center" role="alert">Data Transaksi Berhasil dihapus...!</div>');
    }

    //function untuk menampilkan halaman proses hitung
    public function prshitung()
    {
        return view('admin.proses-hitung',[

            'title' => 'Proses Hitung',
            'penjualan' => Penjualan::orderBy('tahun_id','asc')->orderBy('bulan_id','asc')->get(),
            'nodf' => 1,
        ]);
    }

    //function untuk memulai proses perhitungan
    public function mulaiprs(Request $request)
    {
        //reset data total setiap item
        Dtpertahun::truncate();
        Forecastingtotal::truncate();
        Forecastingbalon::truncate();
        Forecastingboneka::truncate();
        Forecastingbunga::truncate();
        Forecastingsnack::truncate();
        Forecastinguang::truncate();
        Mape::truncate();
        Alfa::truncate();

        $getTahun = Tahun::get();
        $getJual = Penjualan::get();

        for ($i=0; $i < count($getTahun); $i++) {

            $jumbalon = 0;
            $jumboneka = 0;
            $jumbunga = 0;
            $jumsnack = 0;
            $jumuang = 0;
            $jumtotal = 0; 
            
           for ($j=0; $j < count($getJual); $j++) { 
               
               if ($getTahun[$i]->id==$getJual[$j]->tahun_id) {
                   
                   $jumbalon += $getJual[$j]->balon;
                   $jumboneka += $getJual[$j]->boneka;
                   $jumbunga += $getJual[$j]->bunga;
                   $jumsnack += $getJual[$j]->snack;
                   $jumuang += $getJual[$j]->uang;
                   $jumtotal += $getJual[$j]->total;
               }
           }

           $svDataPertahun = new Dtpertahun;
           $svDataPertahun->tahun_id = $getTahun[$i]->id;
           $svDataPertahun->balon = $jumbalon;
           $svDataPertahun->boneka = $jumboneka;
           $svDataPertahun->bunga = $jumbunga;
           $svDataPertahun->snack = $jumsnack;
           $svDataPertahun->uang = $jumuang;
           $svDataPertahun->total = $jumtotal;
           $svDataPertahun->save();
        }

        //memulai proses peramalan untuk total data keseluruhan data pertahun
        $pertahun = Dtpertahun::whereNotIn('total',[0])->get();

        $svAlfa = new Alfa;
        $svAlfa->alfa = $request->alpa;
        $svAlfa->save();

        $nil_alpa = $request->alpa;

        for ($i=0; $i < count($pertahun); $i++) { 
            
            if ($i==0) {
                
                $svFortotal = new Forecastingtotal;
                $svFortotal->tahun = $pertahun[$i]->tahun->tahun;
                $svFortotal->total = $pertahun[$i]->total;
                $svFortotal->smooth1 = $pertahun[$i]->total;
                $svFortotal->smooth2 = $pertahun[$i]->total;
                $svFortotal->konstanta = 0;
                $svFortotal->slope = 0;
                $svFortotal->forecasting = 0;
                $svFortotal->error = 0;
                $svFortotal->save();

            }else{

                if ($i==1) {

                    $getFortotal = Forecastingtotal::latest()->first();
                     
                    $svFortotal = new Forecastingtotal;
                    $svFortotal->tahun = $pertahun[$i]->tahun->tahun;
                    $svFortotal->total = $pertahun[$i]->total;

                    $smooth1 = ($nil_alpa*$pertahun[$i]->total)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;;

                    $svFortotal->forecasting = $forecasting;

                    $error = 0;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                }else{

                    $getFortotal = Forecastingtotal::where('id',$i)->first();

                    $svFortotal = new Forecastingtotal;
                    $svFortotal->tahun = $pertahun[$i]->tahun->tahun;
                    $svFortotal->total = $pertahun[$i]->total;

                    $smooth1 = ($nil_alpa*$pertahun[$i]->total)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;

                    $svFortotal->forecasting = $forecasting;

                    $error = ($pertahun[$i]->total-$forecasting)/$pertahun[$i]->total;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                } 
            }
        }

        //menghitung nilai mape dari forecasting total keseluruhan
        $fortotal = Forecastingtotal::get();

        $getFortotall = Forecastingtotal::where('id',count($fortotal))->first();

        $svMape = new Mape;
        $svMape->keterangan = 'Keseluruhan';
        $svMape->mape = (1/count($fortotal))*$getFortotall->error;
        $svMape->save();
        
        //akhir dari perhitungan peramalan untuk total data keseluruhan pertahun

        //memulai proses peramalan untuk total data penjualan balon pertahun
        $pertahunbalon = Dtpertahun::whereNotIn('balon',[0])->get();

        for ($i=0; $i < count($pertahunbalon); $i++) { 
            
            if ($i==0) {
                
                $svFortotal = new Forecastingbalon;
                $svFortotal->tahun = $pertahunbalon[$i]->tahun->tahun;
                $svFortotal->balon = $pertahunbalon[$i]->balon;
                $svFortotal->smooth1 = $pertahunbalon[$i]->balon;
                $svFortotal->smooth2 = $pertahunbalon[$i]->balon;
                $svFortotal->konstanta = 0;
                $svFortotal->slope = 0;
                $svFortotal->forecasting = 0;
                $svFortotal->error = 0;
                $svFortotal->save();

            }else{

                if ($i==1) {

                    $getFortotal = Forecastingbalon::latest()->first();
                     
                    $svFortotal = new Forecastingbalon;
                    $svFortotal->tahun = $pertahunbalon[$i]->tahun->tahun;
                    $svFortotal->balon = $pertahunbalon[$i]->balon;

                    $smooth1 = ($nil_alpa*$pertahunbalon[$i]->balon)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;;

                    $svFortotal->forecasting = $forecasting;

                    $error = 0;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                }else{

                    $getFortotal = Forecastingbalon::where('id',$i)->first();

                    $svFortotal = new Forecastingbalon;
                    $svFortotal->tahun = $pertahunbalon[$i]->tahun->tahun;
                    $svFortotal->balon = $pertahunbalon[$i]->balon;

                    $smooth1 = ($nil_alpa*$pertahunbalon[$i]->balon)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;

                    $svFortotal->forecasting = $forecasting;

                    $error = ($pertahunbalon[$i]->balon-$forecasting)/$pertahunbalon[$i]->balon;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                } 
            }
        }

        //menghitunga niali mape dari buket balon
        $fortotal = Forecastingbalon::get();

        $getFortotall = Forecastingbalon::where('id',count($fortotal))->first();

        $svMape = new Mape;
        $svMape->keterangan = 'Balon';
        $svMape->mape = (1/count($fortotal))*$getFortotall->error;
        $svMape->save();
        
        //akhir dari perhitungan peramalan untuk data penjualan balon pertahun

        //memulai proses peramalan untuk total data penjualan boneka pertahun
        $pertahunboneka = Dtpertahun::whereNotIn('boneka',[0])->get();

        for ($i=0; $i < count($pertahunboneka); $i++) { 
            
            if ($i==0) {
                
                $svFortotal = new Forecastingboneka;
                $svFortotal->tahun = $pertahunboneka[$i]->tahun->tahun;
                $svFortotal->boneka = $pertahunboneka[$i]->boneka;
                $svFortotal->smooth1 = $pertahunboneka[$i]->boneka;
                $svFortotal->smooth2 = $pertahunboneka[$i]->boneka;
                $svFortotal->konstanta = 0;
                $svFortotal->slope = 0;
                $svFortotal->forecasting = 0;
                $svFortotal->error = 0;
                $svFortotal->save();

            }else{

                if ($i==1) {

                    $getFortotal = Forecastingboneka::latest()->first();
                     
                    $svFortotal = new Forecastingboneka;
                    $svFortotal->tahun = $pertahunboneka[$i]->tahun->tahun;
                    $svFortotal->boneka = $pertahunboneka[$i]->boneka;

                    $smooth1 = ($nil_alpa*$pertahunboneka[$i]->boneka)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;;

                    $svFortotal->forecasting = $forecasting;

                    $error = 0;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                }else{

                    $getFortotal = Forecastingboneka::where('id',$i)->first();

                    $svFortotal = new Forecastingboneka;
                    $svFortotal->tahun = $pertahunboneka[$i]->tahun->tahun;
                    $svFortotal->boneka = $pertahunboneka[$i]->boneka;

                    $smooth1 = ($nil_alpa*$pertahunboneka[$i]->boneka)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;

                    $svFortotal->forecasting = $forecasting;

                    $error = ($pertahunboneka[$i]->boneka-$forecasting)/$pertahunboneka[$i]->boneka;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                } 
            }
        }

        //menghitung nilai mape dari buket boneka
        $fortotal = Forecastingboneka::get();

        $getFortotall = Forecastingboneka::where('id',count($fortotal))->first();

        $svMape = new Mape;
        $svMape->keterangan = 'Boneka';
        $svMape->mape = (1/count($fortotal))*$getFortotall->error;
        $svMape->save();
        
        //akhir dari perhitungan peramalan untuk data penjualan boneka pertahun

        //memulai proses peramalan untuk total data penjualan bunga pertahun
        $pertahunbunga = Dtpertahun::whereNotIn('bunga',[0])->get();

        for ($i=0; $i < count($pertahunbunga); $i++) { 
            
            if ($i==0) {
                
                $svFortotal = new Forecastingbunga;
                $svFortotal->tahun = $pertahunbunga[$i]->tahun->tahun;
                $svFortotal->bunga = $pertahunbunga[$i]->bunga;
                $svFortotal->smooth1 = $pertahunbunga[$i]->bunga;
                $svFortotal->smooth2 = $pertahunbunga[$i]->bunga;
                $svFortotal->konstanta = 0;
                $svFortotal->slope = 0;
                $svFortotal->forecasting = 0;
                $svFortotal->error = 0;
                $svFortotal->save();

            }else{

                if ($i==1) {

                    $getFortotal = Forecastingbunga::latest()->first();
                     
                    $svFortotal = new Forecastingbunga;
                    $svFortotal->tahun = $pertahunbunga[$i]->tahun->tahun;
                    $svFortotal->bunga = $pertahunbunga[$i]->bunga;

                    $smooth1 = ($nil_alpa*$pertahunbunga[$i]->bunga)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;;

                    $svFortotal->forecasting = $forecasting;

                    $error = 0;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                }else{

                    $getFortotal = Forecastingbunga::where('id',$i)->first();

                    $svFortotal = new Forecastingbunga;
                    $svFortotal->tahun = $pertahunbunga[$i]->tahun->tahun;
                    $svFortotal->bunga = $pertahunbunga[$i]->bunga;

                    $smooth1 = ($nil_alpa*$pertahunbunga[$i]->bunga)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;

                    $svFortotal->forecasting = $forecasting;

                    $error = ($pertahunbunga[$i]->bunga-$forecasting)/$pertahunbunga[$i]->bunga;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                } 
            }
        }

        //menghitung nilai mape dari buket bunga
        $fortotal = Forecastingbunga::get();

        $getFortotall = Forecastingbunga::where('id',count($fortotal))->first();

        $svMape = new Mape;
        $svMape->keterangan = 'Bunga';
        $svMape->mape = (1/count($fortotal))*$getFortotall->error;
        $svMape->save();
        
        //akhir dari perhitungan peramalan untuk data penjualan bunga pertahun


        //memulai proses peramalan untuk total data penjualan snack pertahun
        $pertahunsnack = Dtpertahun::whereNotIn('snack',[0])->get();

        for ($i=0; $i < count($pertahunsnack); $i++) { 
            
            if ($i==0) {
                
                $svFortotal = new Forecastingsnack;
                $svFortotal->tahun = $pertahunsnack[$i]->tahun->tahun;
                $svFortotal->snack = $pertahunsnack[$i]->snack;
                $svFortotal->smooth1 = $pertahunsnack[$i]->snack;
                $svFortotal->smooth2 = $pertahunsnack[$i]->snack;
                $svFortotal->konstanta = 0;
                $svFortotal->slope = 0;
                $svFortotal->forecasting = 0;
                $svFortotal->error = 0;
                $svFortotal->save();

            }else{

                if ($i==1) {

                    $getFortotal = Forecastingsnack::latest()->first();
                     
                    $svFortotal = new Forecastingsnack;
                    $svFortotal->tahun = $pertahunsnack[$i]->tahun->tahun;
                    $svFortotal->snack = $pertahunsnack[$i]->snack;

                    $smooth1 = ($nil_alpa*$pertahunsnack[$i]->snack)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;;

                    $svFortotal->forecasting = $forecasting;

                    $error = 0;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                }else{

                    $getFortotal = Forecastingsnack::where('id',$i)->first();

                    $svFortotal = new Forecastingsnack;
                    $svFortotal->tahun = $pertahunsnack[$i]->tahun->tahun;
                    $svFortotal->snack = $pertahunsnack[$i]->snack;

                    $smooth1 = ($nil_alpa*$pertahunsnack[$i]->snack)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;

                    $svFortotal->forecasting = $forecasting;

                    $error = ($pertahunsnack[$i]->snack-$forecasting)/$pertahunsnack[$i]->snack;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                } 
            }
        }

        //menghitung nilai mape dari buket snack
        $fortotal = Forecastingsnack::get();

        $getFortotall = Forecastingsnack::where('id',count($fortotal))->first();

        $svMape = new Mape;
        $svMape->keterangan = 'Snack';
        $svMape->mape = (1/count($fortotal))*$getFortotall->error;
        $svMape->save();
        
        //akhir dari perhitungan peramalan untuk data penjualan snack pertahun

        //memulai proses peramalan untuk total data penjualan uang pertahun
        $pertahunuang = Dtpertahun::whereNotIn('uang',[0])->get();

        for ($i=0; $i < count($pertahunuang); $i++) { 
            
            if ($i==0) {
                
                $svFortotal = new Forecastinguang;
                $svFortotal->tahun = $pertahunuang[$i]->tahun->tahun;
                $svFortotal->uang = $pertahunuang[$i]->uang;
                $svFortotal->smooth1 = $pertahunuang[$i]->uang;
                $svFortotal->smooth2 = $pertahunuang[$i]->uang;
                $svFortotal->konstanta = 0;
                $svFortotal->slope = 0;
                $svFortotal->forecasting = 0;
                $svFortotal->error = 0;
                $svFortotal->save();

            }else{

                if ($i==1) {

                    $getFortotal = Forecastinguang::latest()->first();
                     
                    $svFortotal = new Forecastinguang;
                    $svFortotal->tahun = $pertahunuang[$i]->tahun->tahun;
                    $svFortotal->uang = $pertahunuang[$i]->uang;

                    $smooth1 = ($nil_alpa*$pertahunuang[$i]->uang)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;;

                    $svFortotal->forecasting = $forecasting;

                    $error = 0;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                }else{

                    $getFortotal = Forecastinguang::where('id',$i)->first();

                    $svFortotal = new Forecastinguang;
                    $svFortotal->tahun = $pertahunuang[$i]->tahun->tahun;
                    $svFortotal->uang = $pertahunuang[$i]->uang;

                    $smooth1 = ($nil_alpa*$pertahunuang[$i]->uang)+((1-$nil_alpa)*$getFortotal->smooth1);

                    $svFortotal->smooth1 = $smooth1;

                    $smooth2 = ($nil_alpa*$smooth1)+((1-$nil_alpa)*$getFortotal->smooth2);

                    $svFortotal->smooth2 = $smooth2;

                    $konstanta = (2*$smooth1)-$smooth2;

                    $svFortotal->konstanta = $konstanta;

                    $slope = ($nil_alpa/(1-$nil_alpa))*($smooth1-$smooth2);

                    $svFortotal->slope = $slope;

                    $forecasting = $getFortotal->konstanta+$getFortotal->slope;

                    $svFortotal->forecasting = $forecasting;

                    $error = ($pertahunuang[$i]->uang-$forecasting)/$pertahunuang[$i]->uang;
                        
                    $svFortotal->error = $error;

                    $svFortotal->save();

                } 
            }
        }

        //menghitung nilai mape dari buket uang
        $fortotal = Forecastinguang::get();

        $getFortotall = Forecastinguang::where('id',count($fortotal))->first();

        $svMape = new Mape;
        $svMape->keterangan = 'Uang';
        $svMape->mape = (1/count($fortotal))*$getFortotall->error;
        $svMape->save();
        //akhir dari perhitungan peramalan untuk data penjualan uang pertahun

        return view('admin.hasil-hitung',[

            'title' => 'Hasil Perhitungan',
            'pertahun' => Dtpertahun::get(),
            'nodf' => 1,
            'alfa' => Alfa::latest()->first(),
            
            'balon' => Forecastingbalon::get(),
            'ltbalon' => Forecastingbalon::latest()->first(),
            'mpbalon' => Mape::where('keterangan','Balon')->first(),
            'dbalon' => 1,

            'boneka' => Forecastingboneka::get(),
            'ltboneka' => Forecastingboneka::latest()->first(),
            'mpboneka' => Mape::where('keterangan','Boneka')->first(),
            'dboneka' => 1,

            'bunga' => Forecastingbunga::get(),
            'ltbunga' => Forecastingbunga::latest()->first(),
            'mpbunga' => Mape::where('keterangan','Bunga')->first(),
            'dbunga' => 1,

            'snack' => Forecastingsnack::get(),
            'ltsnack' => Forecastingsnack::latest()->first(),
            'mpsnack' => Mape::where('keterangan','Snack')->first(),
            'dsnack' => 1,

            'uang' => Forecastinguang::get(),
            'ltuang' => Forecastinguang::latest()->first(),
            'mpuang' => Mape::where('keterangan','Uang')->first(),
            'duang' => 1,

            'total' => Forecastingtotal::get(),
            'lttotal' => Forecastingtotal::latest()->first(),
            'mptotal' => Mape::where('keterangan','Keseluruhan')->first(),
            'dtotal' => 1,
        ]);
    }

    //function untuk menampilkan halaman data hasil
    public function hasil()
    {
        //mengambil forecasting total keseluruhan
        $getTotal = Forecastingtotal::all();

        $arrTahun = [];
        $arrAktual = [];
        $arrPrediksi = [];

        $limiter = count($getTotal)-1;

        for ($i=0; $i <= $limiter; $i++) { 

            $arrTahun[] = $getTotal[$i]->tahun;
            $arrAktual[] = $getTotal[$i]->total;
            $arrPrediksi[] = round($getTotal[$i]->forecasting);
        }

        $getEndTotal = Forecastingtotal::latest()->first();

        $arrTahun[] = $getEndTotal->tahun+1;
        $arrPrediksi[] = round($getEndTotal->konstanta+($getEndTotal->slope*1));

        //mengambil forecasting untuk buket balon
        $getTotalbalon = Forecastingbalon::whereNotIn('balon',[0])->get();

        $arrTahunbalon = [];
        $arrAktualbalon = [];
        $arrPrediksibalon = [];

        $limiter = count($getTotalbalon)-1;

        for ($i=0; $i <= $limiter; $i++) { 

            $arrTahunbalon[] = $getTotalbalon[$i]->tahun;
            $arrAktualbalon[] = $getTotalbalon[$i]->balon;
            $arrPrediksibalon[] = round($getTotalbalon[$i]->forecasting);
        }

        $getEndTotalbalon = Forecastingbalon::latest()->first();

        $arrTahunbalon[] = $getEndTotalbalon->tahun+1;
        $arrPrediksibalon[] = round($getEndTotalbalon->konstanta+($getEndTotalbalon->slope*1));

        //mengambil forecasting untuk buket boneka
        $getTotalboneka = Forecastingboneka::whereNotIn('boneka',[0])->get();

        $arrTahunboneka = [];
        $arrAktualboneka = [];
        $arrPrediksiboneka = [];

        $limiter = count($getTotalboneka)-1;

        for ($i=0; $i <= $limiter; $i++) { 

            $arrTahunboneka[] = $getTotalboneka[$i]->tahun;
            $arrAktualboneka[] = $getTotalboneka[$i]->boneka;
            $arrPrediksiboneka[] = round($getTotalboneka[$i]->forecasting);
        }

        $getEndTotalboneka = Forecastingboneka::latest()->first();

        $arrTahunboneka[] = $getEndTotalboneka->tahun+1;
        $arrPrediksiboneka[] = round($getEndTotalboneka->konstanta+($getEndTotalboneka->slope*1));

        //mengambil forecasting untuk buket bunga
        $getTotalbunga = Forecastingbunga::whereNotIn('bunga',[0])->get();

        $arrTahunbunga = [];
        $arrAktualbunga = [];
        $arrPrediksibunga = [];

        $limiter = count($getTotalbunga)-1;

        for ($i=0; $i <= $limiter; $i++) { 

            $arrTahunbunga[] = $getTotalbunga[$i]->tahun;
            $arrAktualbunga[] = $getTotalbunga[$i]->bunga;
            $arrPrediksibunga[] = round($getTotalbunga[$i]->forecasting);
        }

        $getEndTotalbunga = Forecastingbunga::latest()->first();

        $arrTahunbunga[] = $getEndTotalbunga->tahun+1;
        $arrPrediksibunga[] = round($getEndTotalbunga->konstanta+($getEndTotalbunga->slope*1));

        //mengambil forecasting untuk buket snack
        $getTotalsnack = Forecastingsnack::whereNotIn('snack',[0])->get();

        $arrTahunsnack = [];
        $arrAktualsnack = [];
        $arrPrediksisnack = [];

        $limiter = count($getTotalsnack)-1;

        for ($i=0; $i <= $limiter; $i++) { 

            $arrTahunsnack[] = $getTotalsnack[$i]->tahun;
            $arrAktualsnack[] = $getTotalsnack[$i]->snack;
            $arrPrediksisnack[] = round($getTotalsnack[$i]->forecasting);
        }

        $getEndTotalsnack = Forecastingsnack::latest()->first();

        $arrTahunsnack[] = $getEndTotalsnack->tahun+1;
        $arrPrediksisnack[] = round($getEndTotalsnack->konstanta+($getEndTotalsnack->slope*1));

        //mengambil forecasting untuk buket uang
        $getTotaluang = Forecastinguang::whereNotIn('uang',[0])->get();

        $arrTahunuang = [];
        $arrAktualuang = [];
        $arrPrediksiuang = [];

        $limiter = count($getTotaluang)-1;

        for ($i=0; $i <= $limiter; $i++) { 

            $arrTahunuang[] = $getTotaluang[$i]->tahun;
            $arrAktualuang[] = $getTotaluang[$i]->uang;
            $arrPrediksiuang[] = round($getTotaluang[$i]->forecasting);
        }

        $getEndTotaluang = Forecastinguang::latest()->first();

        $arrTahunuang[] = $getEndTotaluang->tahun+1;
        $arrPrediksiuang[] = round($getEndTotaluang->konstanta+($getEndTotaluang->slope*1));

        return view('admin.data-hasil',[

            'title' => 'Data Hasil',
            'datahasil' => 'datahasil',
            'pertahun' => Dtpertahun::get(),
            'nodf' => 1,
            'alfa' => Alfa::latest()->first(),
            
            'arrTahunbalon' => $arrTahunbalon,
            'arrAktualbalon' => $arrAktualbalon,
            'arrPrediksibalon' => $arrPrediksibalon,
            'balon' => Forecastingbalon::get(),
            'ltbalon' => Forecastingbalon::latest()->first(),
            'mpbalon' => Mape::where('keterangan','Balon')->first(),
            'dbalon' => 1,

            'arrTahunboneka' => $arrTahunboneka,
            'arrAktualboneka' => $arrAktualboneka,
            'arrPrediksiboneka' => $arrPrediksiboneka,
            'boneka' => Forecastingboneka::get(),
            'ltboneka' => Forecastingboneka::latest()->first(),
            'mpboneka' => Mape::where('keterangan','Boneka')->first(),
            'dboneka' => 1,

            'arrTahunbunga' => $arrTahunbunga,
            'arrAktualbunga' => $arrAktualbunga,
            'arrPrediksibunga' => $arrPrediksibunga,
            'bunga' => Forecastingbunga::get(),
            'ltbunga' => Forecastingbunga::latest()->first(),
            'mpbunga' => Mape::where('keterangan','Bunga')->first(),
            'dbunga' => 1,

            'arrTahunsnack' => $arrTahunsnack,
            'arrAktualsnack' => $arrAktualsnack,
            'arrPrediksisnack' => $arrPrediksisnack,
            'snack' => Forecastingsnack::get(),
            'ltsnack' => Forecastingsnack::latest()->first(),
            'mpsnack' => Mape::where('keterangan','Snack')->first(),
            'dsnack' => 1,

            'arrTahunuang' => $arrTahunuang,
            'arrAktualuang' => $arrAktualuang,
            'arrPrediksiuang' => $arrPrediksiuang,
            'uang' => Forecastinguang::get(),
            'ltuang' => Forecastinguang::latest()->first(),
            'mpuang' => Mape::where('keterangan','Uang')->first(),
            'duang' => 1,

            'arrTahun' => $arrTahun,
            'arrAktual' => $arrAktual,
            'arrPrediksi' => $arrPrediksi,
            'total' => Forecastingtotal::get(),
            'lttotal' => Forecastingtotal::latest()->first(),
            'mptotal' => Mape::where('keterangan','Keseluruhan')->first(),
            'dtotal' => 1,
        ]);
    }

    //melakukan proses logout
    public function logout()
    {
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();

        return redirect('login')->with('login','<div class="alert alert-success text-center" role="alert">Logout...!</div>');
    }
}
