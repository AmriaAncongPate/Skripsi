<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\Admin\AdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/login',[LoginController::class,'index'])->name('login')->middleware('guest');
Route::post('/login',[LoginController::class,'login']);

Route::get('/',[AdminController::class,'index'])->middleware('auth');
Route::get('/buket',[AdminController::class,'buket'])->middleware('auth');
Route::get('/edtbuket/{buket:id}',[AdminController::class,'edtbuket'])->middleware('auth');
Route::post('/updatebkt',[AdminController::class,'updatebkt'])->middleware('auth');

Route::get('/transaksi',[AdminController::class,'transaksi'])->middleware('auth');
Route::match(['get','post'],'/addtransaksi',[AdminController::class,'addtransaksi'])->middleware('auth');
Route::get('/edtransaksi/{penjualan:id}',[AdminController::class,'edtransaksi'])->middleware('auth');
Route::post('/updatetrn',[AdminController::class,'updatetrn'])->middleware('auth');
Route::get('/deltransaksi/{penjualan:id}',[AdminController::class,'deltransaksi'])->middleware('auth');

Route::get('/prshitung',[AdminController::class,'prshitung'])->middleware('auth');
Route::post('/mulaiprs',[AdminController::class,'mulaiprs'])->middleware('auth');
Route::get('/hasil',[AdminController::class,'hasil'])->middleware('auth');

Route::get('/logout',[AdminController::class,'logout'])->middleware('auth');