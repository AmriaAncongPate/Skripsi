@extends('tempadmin.main')
@section('container')
<div class="container-fluid">
    <div class="row">
        <dov class="col-lg-12">
            @if(Session::has('prshitung'))
            {!!Session::get('prshitung')!!}
            @endif
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">{{$title}}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive mb-4">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Bulan</th>
                                    <th>Tahun</th>
                                    <th>B. Balon</th>
                                    <th>B. Boneka</th>
                                    <th>B. Bunga</th>
                                    <th>B. Snack</th>
                                    <th>B. Uang</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($penjualan as $pjl)
                                <tr>
                                    <td>{{$nodf++}}</td>
                                    <td>{{$pjl->bulan->bulan}}</td>
                                    <td>{{$pjl->tahun->tahun}}</td>
                                    <td>{{$pjl->balon}}</td>
                                    <td>{{$pjl->boneka}}</td>
                                    <td>{{$pjl->bunga}}</td>
                                    <td>{{$pjl->snack}}</td>
                                    <td>{{$pjl->uang}}</td>
                                    <td>{{$pjl->total}}</td>                             
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <form action="/mulaiprs" method="post">
                        @csrf
                        <div class="mb-3">
                      <label for="alpa" class="form-label">Koefisien Pemulusan (Smoothing)</label>
                      <input type="number" class="form-control" id="alpa" step="any" name="alpa" placeholder="Masukkan nilai pemulusan" required>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Mulai Perhitungan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4"><strong>Analisis Metode Double Exponential Smoothing Untuk Prediksi Penjualan Buket Pada Toko Schoene Florist</strong></p>
    </div>
</div>
@endsection
